﻿namespace DeliveryCharges
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnCheckDelivery;
        private System.Windows.Forms.TextBox txtZipCode;

        // Auto-generated code for form design

        private void InitializeComponent()
        {
            this.btnCheckDelivery = new System.Windows.Forms.Button();
            this.txtZipCode = new System.Windows.Forms.TextBox();
            // 
            // btnCheckDelivery
            // 
            this.btnCheckDelivery.Location = new System.Drawing.Point(148, 61);
            this.btnCheckDelivery.Name = "btnCheckDelivery";
            this.btnCheckDelivery.Size = new System.Drawing.Size(117, 23);
            this.btnCheckDelivery.TabIndex = 0;
            this.btnCheckDelivery.Text = "Check Delivery";
            this.btnCheckDelivery.UseVisualStyleBackColor = true;
            this.btnCheckDelivery.Click += new System.EventHandler(this.btnCheckDelivery_Click);
            // 
            // txtZipCode
            // 
            this.txtZipCode.Location = new System.Drawing.Point(44, 61);
            this.txtZipCode.Name = "txtZipCode";
            this.txtZipCode.Size = new System.Drawing.Size(78, 20);
            this.txtZipCode.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 117);
            this.Controls.Add(this.txtZipCode);
            this.Controls.Add(this.btnCheckDelivery);
            this.Name = "Form1";
            this.Text = "Delivery Charges";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
