using System;
using System.Windows.Forms;

namespace DeliveryCharges
{
    public partial class Form1 : Form
    {
        // Arrays to hold zip codes and delivery charges
        int[] zipCodes = { 12345, 23456, 34567, 45678, 56789, 67890, 78901, 89012, 90123, 91234 };
        double[] deliveryCharges = { 5.99, 6.99, 7.99, 8.99, 9.99, 10.99, 11.99, 12.99, 13.99, 14.99 };

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCheckDelivery_Click(object sender, EventArgs e)
        {
            // Get the entered zip code
            int zipCode;
            if (!int.TryParse(txtZipCode.Text, out zipCode))
            {
                MessageBox.Show("Please enter a valid zip code.");
                return;
            }

            // Search for the zip code in the array
            int index = Array.IndexOf(zipCodes, zipCode);
            if (index != -1)
            {
                // Display the delivery charge if zip code is found
                MessageBox.Show($"Delivery charge for zip code {zipCode}: ${deliveryCharges[index]}");
            }
            else
            {
                // Display message if zip code is not found
                MessageBox.Show($"We do not deliver to the zip code {zipCode}.");
            }
        }
    }
}
